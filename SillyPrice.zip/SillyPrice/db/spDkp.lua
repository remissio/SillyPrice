spDkp = {}
spDkp  = {
  [21702]={
    [1]={
      ["name"]="Amulet of Foul Warding",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21608]={
    [1]={
      ["name"]="Amulet of Vek'nilash",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21650]={
    [1]={
      ["name"]="Ancient Qiraji Ripper",["value"]="200",["note"]="",["role"]="Melee DPS"
      }
    },
  [21690]={
    [1]={
      ["name"]="Angelista's Charm",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21695]={
    [1]={
      ["name"]="Angelista's Touch",["value"]="200",["note"]="",["role"]="Tanks"
      }
    },
  [21837]={
    [1]={
      ["name"]="Anubisath Warhammer",["value"]="200",["note"]="",["role"]="physical DPS"
      }
    },
  [21670]={
    [1]={
      ["name"]="Badge of the Swarmguard",["value"]="200",["note"]="",["role"]="Schurken, Krieger DPS"
      }
    },
  [21635]={
    [1]={
      ["name"]="Barb of the Sand Reaver",["value"]="200",["note"]="",["role"]="Hunter, Ferals"
      }
    },
  [21664]={
    [1]={
      ["name"]="Barbed Choker",["value"]="200",["note"]="",["role"]="physical DPS"
      }
    },
  [21699]={
    [1]={
      ["name"]="Barrage Shoulders",["value"]="200",["note"]="",["role"]="Hunter, Enhancer"
      }
    },
  [21708]={
    [1]={
      ["name"]="Beetle Scaled Wristguards",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21586]={
    [1]={
      ["name"]="Belt of Never-ending Agony",["value"]="200",["note"]="",["role"]="Schurken"
      }
    },
  [21682]={
    [1]={
      ["name"]="Bile-Covered Gauntlets",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21600]={
    [1]={
      ["name"]="Boots of Epiphany",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21688]={
    [1]={
      ["name"]="Boots of the Fallen Hero",["value"]="200",["note"]="",["role"]="Krieger DPS"
      }
    },
  [21705]={
    [1]={
      ["name"]="Boots of the Fallen Prophet",["value"]="200",["note"]="",["role"]="Schamanen"
      }
    },
  [21704]={
    [1]={
      ["name"]="Boots of the Redeemed Prophecy",["value"]="200",["note"]="",["role"]="Gast-Paladine"
      }
    },
  [21706]={
    [1]={
      ["name"]="Boots of the Unwavering Will",["value"]="200",["note"]="",["role"]="Krieger"
      }
    },
  [21604]={
    [1]={
      ["name"]="Bracelets of Royal Redemption",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21814]={
    [1]={
      ["name"]="Breastplate of Annihilation",["value"]="200",["note"]="",["role"]="Krieger DPS"
      }
    },
  [21611]={
    [1]={
      ["name"]="Burrower Bracers",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21697]={
    [1]={
      ["name"]="Cape of the Trinity",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21583]={
    [1]={
      ["name"]="Cloak of Clarity",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21701]={
    [1]={
      ["name"]="Cloak of Concentrated Hatred",["value"]="200",["note"]="",["role"]="1. Enhancer, 2. Krieger DPS/Schurken"
      }
    },
  [22731]={
    [1]={
      ["name"]="Cloak of the Devoured",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21621]={
    [1]={
      ["name"]="Cloak of the Golden Hive",["value"]="200",["note"]="",["role"]="Tanks"
      }
    },
  [21627]={
    [1]={
      ["name"]="Cloak of Untold Secrets",["value"]="200",["note"]="",["role"]="Warlock (twintank)"
      }
    },
  [21669]={
    [1]={
      ["name"]="Creeping Vine Helm",["value"]="200",["note"]="",["role"]="Druiden"
      }
    },
  [21134]={
    [1]={
      ["name"]="Dark Edge of Insanity",["value"]="200",["note"]="",["role"]="Krieger, Schamanen"
      }
    },
  [21585]={
    [1]={
      ["name"]="Dark Storm Gauntlets",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21126]={
    [1]={
      ["name"]="Death's Sting",["value"]="200",["note"]="",["role"]="1. Dolchschurken, 2. Tanks"
      }
    },
  [21615]={
    [1]={
      ["name"]="Don Rigoberto's Lost Hat",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [22730]={
    [1]={
      ["name"]="Eyestalk Waist Cord",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21647]={
    [1]={
      ["name"]="Fetish of the Sand Reaver",["value"]="200",["note"]="Belgier, ganz klar Belgier!",["role"]="1. Belgier, 2. ffa"
      }
    },
  [21581]={
    [1]={
      ["name"]="Gauntlets of Annihilation",["value"]="200",["note"]="",["role"]="Krieger DPS"
      }
    },
  [21624]={
    [1]={
      ["name"]="Gauntlets of Kalimdor",["value"]="200",["note"]="",["role"]="Schamanen"
      }
    },
  [21674]={
    [1]={
      ["name"]="Gauntlets of Steadfast Determination",["value"]="200",["note"]="",["role"]="Krieger"
      }
    },
  [21838]={
    [1]={
      ["name"]="Garb of Royal Ascension",["value"]="200",["note"]="",["role"]="Warlock (twintank)"
      }
    },
  [21689]={
    [1]={
      ["name"]="Gloves of Ebru",["value"]="200",["note"]="",["role"]="Druiden, Schamanen"
      }
    },
  [21672]={
    [1]={
      ["name"]="Gloves of Enforcement",["value"]="200",["note"]="",["role"]="Schurke, Ferals"
      }
    },
  [21605]={
    [1]={
      ["name"]="Gloves of the Hidden Temple",["value"]="200",["note"]="",["role"]="Ferals"
      }
    },
  [21888]={
    [1]={
      ["name"]="Gloves of the Immortal",["value"]="200",["note"]="",["role"]="Warlock (twintank)"
      }
    },
  [21619]={
    [1]={
      ["name"]="Gloves of the Messiah",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21607]={
    [1]={
      ["name"]="Grasp of the Fallen Emperor",["value"]="200",["note"]="",["role"]="Schamanen"
      }
    },
  [21582]={
    [1]={
      ["name"]="Grasp of the Old God",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21693]={
    [1]={
      ["name"]="Guise of the Devourer",["value"]="200",["note"]="",["role"]="Ferals"
      }
    },
  [21703]={
    [1]={
      ["name"]="Hammer of Ji'zhi",["value"]="200",["note"]="",["role"]="ffa"
      }
    },
  [21618]={
    [1]={
      ["name"]="Hive Defiler Wristguards",["value"]="200",["note"]="",["role"]="Krieger DPS"
      }
    },
  [21645]={
    [1]={
      ["name"]="Hive Tunneler's Boots",["value"]="200",["note"]="",["role"]="Ferals"
      }
    },
  [21616]={
    [1]={
      ["name"]="Huhuran's Stinger",["value"]="200",["note"]="",["role"]="ffa"
      }
    },
  [22399]={
    [1]={
      ["name"]="Idol of Health",["value"]="200",["note"]="",["role"]="Druidenheiler"
      }
    },
  [23570]={
    [1]={
      ["name"]="Jom Gabbar",["value"]="200",["note"]="",["role"]="physical DPS"
      }
    },
  [21679]={
    [1]={
      ["name"]="Kalimdor's Revenge",["value"]="200",["note"]="",["role"]="Krieger"
      }
    },
  [23557]={
    [1]={
      ["name"]="Larvae of the Great Worm",["value"]="200",["note"]="",["role"]="Hunter"
      }
    },
  [21698]={
    [1]={
      ["name"]="Leggings of Immersion",["value"]="200",["note"]="",["role"]="Druiden, Schamanen"
      }
    },
  [21676]={
    [1]={
      ["name"]="Leggings of the Festering Swarm",["value"]="200",["note"]="",["role"]="Magier"
      }
    },
  [21686]={
    [1]={
      ["name"]="Mantle of Phrenic Power",["value"]="200",["note"]="",["role"]="Magier"
      }
    },
  [21684]={
    [1]={
      ["name"]="Mantle of the Desert's Fury",["value"]="200",["note"]="",["role"]="Schamanen"
      }
    },
  [21665]={
    [1]={
      ["name"]="Mantle of Wicked Revenge",["value"]="200",["note"]="",["role"]="1. Ferals, 2. Enhancer"
      }
    },
  [22732]={
    [1]={
      ["name"]="Mark of C'Thun",["value"]="200",["note"]="",["role"]="Tank"
      }
    },
  [21678]={
    [1]={
      ["name"]="Necklace of Purity",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21856]={
    [1]={
      ["name"]="Neretzek, The Blood Drinker",["value"]="200",["note"]="",["role"]="Krieger, Schamanen"
      }
    },
  [21691]={
    [1]={
      ["name"]="Ooze-ridden Gauntlets",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21639]={
    [1]={
      ["name"]="Pauldrons of the Unrelenting",["value"]="200",["note"]="",["role"]="Krieger"
      }
    },
  [21700]={
    [1]={
      ["name"]="Pendant of the Qiraji Guardian",["value"]="200",["note"]="",["role"]="Tanks"
      }
    },
  [21685]={
    [1]={
      ["name"]="Petrified Scarab",["value"]="200",["note"]="",["role"]="ffa"
      }
    },
  [21602]={
    [1]={
      ["name"]="Qiraji Execution Bracers",["value"]="200",["note"]="",["role"]="1. Ferals, 2. Melee DPS"
      }
    },
  [21648]={
    [1]={
      ["name"]="Recomposed Boots",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21609]={
    [1]={
      ["name"]="Regenerating Belt of Vek'nilash",["value"]="200",["note"]="",["role"]="Druiden, Schamanen"
      }
    },
  [21601]={
    [1]={
      ["name"]="Ring of Emperor Vek'lor",["value"]="200",["note"]="",["role"]="Ferals"
      }
    },
  [21707]={
    [1]={
      ["name"]="Ring of Swarming Thought",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21681]={
    [1]={
      ["name"]="Ring of the Devoured",["value"]="200",["note"]="",["role"]="Druiden, Schamanen"
      }
    },
  [21596]={
    [1]={
      ["name"]="Ring of the Godslayer",["value"]="200",["note"]="",["role"]="ffa"
      }
    },
  [21620]={
    [1]={
      ["name"]="Ring of the Martyr",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21677]={
    [1]={
      ["name"]="Ring of the Qiraji Fury",["value"]="200",["note"]="",["role"]="physcal DPS"
      }
    },
  [21836]={
    [1]={
      ["name"]="Ritssyn's Ring of Chaos",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21671]={
    [1]={
      ["name"]="Robes of the Battleguard",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21663]={
    [1]={
      ["name"]="Robes of the Guardian Saint",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21696]={
    [1]={
      ["name"]="Robes of the Triumvirate",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21598]={
    [1]={
      ["name"]="Royal Qiraji Belt",["value"]="200",["note"]="",["role"]="Tanks"
      }
    },
  [21597]={
    [1]={
      ["name"]="Royal Scepter of Vek'lor",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21666]={
    [1]={
      ["name"]="Sartura's Might",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21668]={
    [1]={
      ["name"]="Scaled Leggings of Qiraji Fury",["value"]="200",["note"]="",["role"]="Schamanen"
      }
    },
  [21651]={
    [1]={
      ["name"]="Scaled Sand Reaver Leggings",["value"]="200",["note"]="",["role"]="Enhancer"
      }
    },
  [21625]={
    [1]={
      ["name"]="Scarab Brooch",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21839]={
    [1]={
      ["name"]="Scepter of the False Prophet",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [21891]={
    [1]={
      ["name"]="Shard of the Fallen Star",["value"]="200",["note"]="",["role"]="ffa"
      }
    },
  [21622]={
    [1]={
      ["name"]="Sharpened Silithid Femur",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21652]={
    [1]={
      ["name"]="Silithid Carapace Chestguard",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21673]={
    [1]={
      ["name"]="Silithid Claw",["value"]="200",["note"]="",["role"]="Hunter"
      }
    },
  [21626]={
    [1]={
      ["name"]="Slime-coated Leggings",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21128]={
    [1]={
      ["name"]="Staff of the Qiraji Prophets",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21694]={
    [1]={
      ["name"]="Ternary Mantle",["value"]="200",["note"]="",["role"]="Heiler"
      }
    },
  [23558]={
    [1]={
      ["name"]="The Burrower's Shell",["value"]="200",["note"]="",["role"]="ffa"
      }
    },
  [21675]={
    [1]={
      ["name"]="Thick Qirajihide Belt",["value"]="200",["note"]="",["role"]="Ferals"
      }
    },
  [22396]={
    [1]={
      ["name"]="Totem of Life",["value"]="200",["note"]="",["role"]="Heilschamanen"
      }
    },
  [21692]={
    [1]={
      ["name"]="Triad Girdle",["value"]="200",["note"]="",["role"]="Krieger"
      }
    },
  [21687]={
    [1]={
      ["name"]="Ukko's Ring of Darkness",["value"]="200",["note"]="",["role"]="Warlock (twintank)"
      }
    },
  [21579]={
    [1]={
      ["name"]="Vanquished Tentacle of C'Thun",["value"]="200",["note"]="",["role"]="ffa"
      }
    },
  [21599]={
    [1]={
      ["name"]="Vek'lor's Gloves of Devastation",["value"]="200",["note"]="",["role"]="Enhancer"
      }
    },
  [21680]={
    [1]={
      ["name"]="Vest of Swift Execution",["value"]="200",["note"]="",["role"]="Ferals, Enhancer"
      }
    },
  [21603]={
    [1]={
      ["name"]="Wand of Qiraji Nobility",["value"]="200",["note"]="",["role"]="Caster DPS"
      }
    },
  [21617]={
    [1]={
      ["name"]="Wasphide Gauntlets",["value"]="200",["note"]="",["role"]="Schamane"
      }
    },
  [21610]={
    [1]={
      ["name"]="Wormscale Blocker",["value"]="200",["note"]="",["role"]="Resigear"
      }
    },
  [21221]={
    [1]={
      ["name"]="Eye of C'Thun",["value"]="111",["note"]="",["role"]="Heiler, Caster"
      }
    },
  [20928]={
    [1]={
      ["name"]="Qiraji Bindings of Command",["value"]="111",["note"]="",["role"]="Schurken"
      }
    },
  [20932]={
    [1]={
      ["name"]="Qiraji Bindings of Dominance",["value"]="111",["note"]="",["role"]="ffa"
      }
    },
  [20930]={
    [1]={
      ["name"]="Vek'lor's Diadem",["value"]="111",["note"]="",["role"]="Schurken"
      }
    },
  [20926]={
    [1]={
      ["name"]="Vek'nilash's Circlet",["value"]="111",["note"]="",["role"]="ffa"
      }
    },
  [20927]={
    [1]={
      ["name"]="Ouro's Intact Hide",["value"]="111",["note"]="",["role"]="Schurken"
      }
    },
  [20931]={
    [1]={
      ["name"]="Skin of the Great Sandworm",["value"]="111",["note"]="",["role"]="ffa"
      }
    },
  [20929]={
    [1]={
      ["name"]="Carapace of the Old God",["value"]="111",["note"]="",["role"]="Schurken"
      }
    },
  [20933]={
    [1]={
      ["name"]="Husk of the Old God",["value"]="111",["note"]="",["role"]="ffa"
      }
    },
  [21232]={
    [1]={
      ["name"]="Imperial Qiraji Armaments",["value"]="111",["note"]="Tanks ohne den BWL Schild!",["role"]="1. Tanks, 2. ffa"
      }
    },
  [21237]={
    [1]={
      ["name"]="Imperial Qiraji Regalia",["value"]="111",["note"]="",["role"]="ffa"
      }
    },
  [19003]={
    [1]={
      ["name"]="Head of Nefarian",["value"]="100",["note"]="",["role"]="1. physical DPS, 2. ffa"
      }
    },
  [19439]={
    [1]={
      ["name"]="Interlaced Shadow Jerkin",["value"]="100",["note"]="",["role"]="???"
      }
    },
  [19392]={
    [1]={
      ["name"]="Girdle of the Fallen Crusader",["value"]="100",["note"]="",["role"]="Krieger"
      }
    },
  [19393]={
    [1]={
      ["name"]="Primalist's Linked Waistguard",["value"]="100",["note"]="",["role"]="Schamanen"
      }
    },
  [19390]={
    [1]={
      ["name"]="Taut Dragonhide Gloves",["value"]="100",["note"]="",["role"]="Druiden, Schamanen"
      }
    },
  [19386]={
    [1]={
      ["name"]="Elementium Threaded Cloak",["value"]="100",["note"]="",["role"]="Tanks"
      }
    },
  [19365]={
    [1]={
      ["name"]="Claw of the Black Drake",["value"]="100",["note"]="",["role"]="Melee DPS"
      }
    },
  [19402]={
    [1]={
      ["name"]="Legguards of the Fallen Crusader",["value"]="100",["note"]="",["role"]="Krieger DPS, Gast-Paladine"
      }
    },
  [19342]={
    [1]={
      ["name"]="Venomous Totem",["value"]="100",["note"]="",["role"]="Schurken"
      }
    },
  [19336]={
    [1]={
      ["name"]="Arcane Infused Gem",["value"]="100",["note"]="",["role"]="Jäger"
      }
    },
  [18813]={
    [1]={
      ["name"]="Ring of Binding",["value"]="0",["note"]="",["role"]="Tanks"
      }
    },     
 [18205]={
    [1]={
      ["name"]="Eskhandar's Collar",["value"]="0",["note"]="",["role"]="Ferals"
      }
    },     
 [18705]={
    [1]={
      ["name"]="Mature Black Dragon Sinew",["value"]="0",["note"]="",["role"]="Diese Typen mit dem Bogen."
      }
    },    
 [18423]={
    [1]={
      ["name"]="Head of Onyxia",["value"]="0",["note"]="",["role"]="1. physical DPS, 2. Rest"
      }
    },   
 [18563]={
    [1]={
      ["name"]="Bindings of the Windseeker",["value"]="0",["note"]="Will einfach nicht droppen -.-",["role"]="Tanks"
      }
    },   
 [18564]={
    [1]={
      ["name"]="Bindings of the Windseeker",["value"]="0",["note"]="",["role"]="Tanks"
      }
    },    
 [18815]={
    [1]={
      ["name"]="Essence of the Pure Flame",["value"]="0",["note"]="",["role"]="Tanks"
      }
    },    
 [19138]={
    [1]={
      ["name"]="Band of Sulfuras",["value"]="0",["note"]="",["role"]="Caster"
      }
    },     
 [17082]={
    [1]={
      ["name"]="Shard of the Flame",["value"]="0",["note"]="",["role"]="niemand braucht sowas"
      }
    },    
 [18646]={
    [1]={
      ["name"]="The Eye of Divinity",["value"]="0",["note"]="",["role"]="Priester"
      }
    },   
 [18703]={
    [1]={
      ["name"]="Ancient Petrified Leaf",["value"]="0",["note"]="",["role"]="Die da mit dem Bogen und so."
      }
    },    
 [18806]={
    [1]={
      ["name"]="Core Forged Greaves",["value"]="0",["note"]="",["role"]="Tanks"
      }
    },   
 [18808]={
    [1]={
      ["name"]="Gloves of the Hypnotic Flame",["value"]="0",["note"]="",["role"]="Magier"
      }
    },  
 [18811]={
    [1]={
      ["name"]="Fireproof Cloak",["value"]="0",["note"]="Resi Gear",["role"]="Caster"
      }
    }, 
 [17110]={
    [1]={
      ["name"]="Seal of the Archmagus",["value"]="0",["note"]="",["role"]="Whatever"
      }
    },
 [17077]={
    [1]={
      ["name"]="Crimson Shocker",["value"]="0",["note"]="",["role"]="Caster"
      }
    },
 [18861]={
    [1]={
      ["name"]="Flamewaker Legplates",["value"]="0",["note"]="",["role"]="Tank"
    }
  },    
  [18872]={
    [1]={
      ["name"]="Manastorm Leggings",["value"]="0",["note"]="",["role"]="Heiler"
    }
  },  
  [16866]={
    [1]={
      ["name"]="Helm of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [17065]={
    [1]={
      ["name"]="Medallion of Steadfast Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [16868]={
    [1]={
      ["name"]="Pauldrons of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [17102]={
    [1]={
      ["name"]="Claok of the Shrouded Mists",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [17107]={
    [1]={
      ["name"]="Dragon's Blood Cape",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [16865]={
    [1]={
      ["name"]="Breastplate of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [16861]={
    [1]={
      ["name"]="Bracers of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [18812]={
    [1]={
      ["name"]="Wristguards of True Flight",["value"]="0",["note"]="",["role"]="Hunter, Schamanen"
    }
  },
  [16863]={
    [1]={
      ["name"]="Gauntles of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [18823]={
    [1]={
      ["name"]="Aged Core Leather Gloves",["value"]="0",["note"]="",["role"]="Dolch Schurken"
    }
  },
  [16864]={
    [1]={
      ["name"]="Belt of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [19137]={
    [1]={
      ["name"]="Onslaught Girdle",["value"]="0",["note"]="",["role"]="Krieger"
    }
  },
  [16962]={
    [1]={
      ["name"]="Legplates of Wrath",["value"]="0",["note"]="",["role"]="Krieger"
    }
  },
  [16867]={
    [1]={
      ["name"]="Legplates of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [16862]={
    [1]={
      ["name"]="Sabotons of Might",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [17063]={
    [1]={
      ["name"]="Band of Accuria",["value"]="0",["note"]="MT's von uns haben es alle!",["role"]="1. Tanks, 2. Melee DPS"
    }
  },
  [18879]={
    [1]={
      ["name"]="Heavy Dark Iron Ring",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [18821]={
    [1]={
      ["name"]="Quick Strike Ring",["value"]="0",["note"]="",["role"]="Melee DPS, Hunter"
    }
  },
  [18203]={
    [1]={
      ["name"]="Eskhandars Right Claw",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [17071]={
    [1]={
      ["name"]="Gutegore Ripper",["value"]="0",["note"]="",["role"]="1. Dolchschurken, 2. Tanks, 3. Melee DPS"
    }
  },
  [18805]={
    [1]={
      ["name"]="Core Hound Tooth",["value"]="0",["note"]="",["role"]="1. Dolch Schurken, 2. Tanks"
    }
  },
  [18832]={
    [1]={
      ["name"]="Brutality Blade",["value"]="0",["note"]="",["role"]="Melee DPS"
    }
  },
  [17068]={
    [1]={
      ["name"]="Deathbringer",["value"]="0",["note"]="",["role"]="Krieger DPS"
    }
  },
  [17075]={
    [1]={
      ["name"]="Vis'kag the Bloodletter",["value"]="0",["note"]="",["role"]="Melee DPS"
    }
  },
  [18816]={
    [1]={
      ["name"]="Perdition's Blade",["value"]="0",["note"]="",["role"]="1. Dolch Schurken, 2. Tanks"
    }
  },
  [17066]={
    [1]={
      ["name"]="Drillborer Disk",["value"]="0",["note"]="",["role"]="Tanks"
    }
  },
  [17072]={
    [1]={
      ["name"]="Blastershot Launcher",["value"]="0",["note"]="",["role"]="Hunter, Melee DPS"
    }
  },
  [17069]={
    [1]={
      ["name"]="Striker's Mark",["value"]="0",["note"]="",["role"]="Melee DPS"
    }
  },
  [19372]={
    [1]={
      ["name"]="Helm of Endless Rage",["value"]="100",["note"]="",["role"]="Krieger"
    }
  },
  [19383]={
    [1]={
      ["name"]="Master Dragonslayer's Medallion",["value"]="100",["note"]="",["role"]="Tanks"
    }
  },
  [16961]={
    [1]={
      ["name"]="Pauldrons of Wrath",["value"]="50",["note"]="",["role"]="Krieger"
    }
  },
  [19394]={
    [1]={
      ["name"]="Drake Talon Pauldrons",["value"]="100",["note"]="",["role"]="Krieger DPS"
    }
  },
  [19436]={
    [1]={
      ["name"]="Cloak of Draconic Might",["value"]="100",["note"]="",["role"]="Melee DPS"
    }
  },
  [16966]={
    [1]={
      ["name"]="Breastplate of Wrath",["value"]="50",["note"]="",["role"]="Krieger"
    }
  },
  [16959]={
    [1]={
      ["name"]="Bracelets of Wrath",["value"]="50",["note"]="",["role"]="Krieger"
    }
  },
  [16964]={
    [1]={
      ["name"]="Gauntlets of Wrath",["value"]="50",["note"]="",["role"]="Krieger"
    }
  },
  [16960]={
    [1]={
      ["name"]="Waistband of Wrath",["value"]="50",["note"]="",["role"]="Krieger"
    }
  },
  [16965]={
    [1]={
      ["name"]="Sabatons of Wrath",["value"]="50",["note"]="",["role"]="Krieger"
    }
  },
  [19387]={
    [1]={
      ["name"]="Chromatic Boots",["value"]="100",["note"]="",["role"]="Krieger DPS"
    }
  },
  [19351]={
    [1]={
      ["name"]="Maladath, Runed Blade of the Black Flight",["value"]="100",["note"]="",["role"]="1. Tanks, 2. Melee DPS"
    }
  },
  [19363]={
    [1]={
      ["name"]="Crul'shorukh, Edge of Chaos",["value"]="100",["note"]="",["role"]="1. Tanks, 2. Krieger DPS"
    }
  },
  [19352]={
    [1]={
      ["name"]="Chromatically Tempered Sword",["value"]="100",["note"]="",["role"]="Melee DPS"
    }
  },
  [19362]={
    [1]={
      ["name"]="Doom's Edge",["value"]="100",["note"]="",["role"]="1. Tanks, 2. Krieger DPS"
    }
  },
  [19335]={
    [1]={
      ["name"]="Spineshatter",["value"]="100",["note"]="",["role"]="Tanks"
    }
  },
  [19346]={
    [1]={
      ["name"]="Dragonfang Blade",["value"]="100",["note"]="",["role"]="1. Dolchschurken, 2. Tanks"
    }
  },
  [19349]={
    [1]={
      ["name"]="Elementium Reinforced Bulwark",["value"]="100",["note"]="",["role"]="Tanks"
    }
  },
  [19368]={
    [1]={
      ["name"]="Dragonbreath Hand Cannon",["value"]="100",["note"]="",["role"]="1. Tanks, 2. Melee DPS"
    }
  },
  [19350]={
    [1]={
      ["name"]="Heartstriker",["value"]="100",["note"]="",["role"]="Melee DPS"
    }
  },
  [19341]={
    [1]={
      ["name"]="Lifegiving Gem",["value"]="100",["note"]="",["role"]="Tanks"
    }
  },
  [19431]={
    [1]={
      ["name"]="Styleen's Impeding Scarab",["value"]="100",["note"]="",["role"]="Tanks"
    }
  },
  [19406]={
    [1]={
      ["name"]="Drake Fang Talisman",["value"]="100",["note"]="",["role"]="1.Tanks, 2.Furies/Schurken, 3.Jäger/Enhancer"
    }
  },
  [16963]={
    [1]={
      ["name"]="Helm of Wrath",["value"]="0",["note"]="",["role"]="Krieger"
    }
  },
  [19146]={
    [1]={
      ["name"]="Wristguards of Stability",["value"]="0",["note"]="",["role"]="Melee DPS"
    }
  },
  [19143]={
    [1]={
      ["name"]="Flameguard Gauntlets",["value"]="0",["note"]="",["role"]="Krieger DPS"
    }
  },
  [17076]={
    [1]={
      ["name"]="Bonereaver's Edge",["value"]="0",["note"]="",["role"]="Krieger DPS"
    }
  },
  [17104]={
    [1]={
      ["name"]="Spinal Reaper",["value"]="0",["note"]="",["role"]="Krieger DPS"
    }
  },
  [18822]={
    [1]={
      ["name"]="Obsidian Edged Blade",["value"]="0",["note"]="",["role"]="Krieger DPS"
    }
  },
  [17073]={
    [1]={
      ["name"]="Earthshaker",["value"]="0",["note"]="",["role"]="Melee DPS"
    }
  },
  [19389]={
    [1]={
      ["name"]="Taut Dragonhide Shoulderpads",["value"]="100",["note"]="",["role"]="Ferals"
    }
  },
  [19398]={
    [1]={
      ["name"]="Cloak of Firemaw",["value"]="100",["note"]="",["role"]="Melee DPS, Jäger"
    }
  },
  [19405]={
    [1]={
      ["name"]="Malfurins Blessed Bulwark",["value"]="100",["note"]="",["role"]="1. Ferals, 2. Krieger DPS"
    }
  },
  [19381]={
    [1]={
      ["name"]="Boots of the Shadow Flame",["value"]="100",["note"]="",["role"]="1. Feral Tanks, 2. Schurken, 3. Schamanen"
    }
  },
  [19384]={
    [1]={
      ["name"]="Master Dragonslayer's Ring",["value"]="100",["note"]="",["role"]="Melee DPS, Jäger"
    }
  },
  [19432]={
    [1]={
      ["name"]="Circle of Applied Force",["value"]="100",["note"]="",["role"]="Melee DPS"
    }
  },
  [19334]={
    [1]={
      ["name"]="The Untamed Blade",["value"]="100",["note"]="",["role"]="Krieger DPS"
    }
  },
  [19364]={
    [1]={
      ["name"]="Ashkandi, Greatsword of the Brotherhood",["value"]="100",["note"]="",["role"]="Krieger DPS"
    }
  },
  [19353]={
    [1]={
      ["name"]="Drake Talon Cleaver",["value"]="100",["note"]="",["role"]="Krieger DPS, Enhancer"
    }
  },
  [19357]={
    [1]={
      ["name"]="Herald of Woe",["value"]="100",["note"]="",["role"]="Schamanen, Druiden"
    }
  },
  [19354]={
    [1]={
      ["name"]="Draconic Avenger",["value"]="100",["note"]="",["role"]="Krieger DPS"
    }
  },
  [19358]={
    [1]={
      ["name"]="Draconic Maul",["value"]="100",["note"]="",["role"]="Krieger DPS, Schamanen, Druiden"
    }
  },
  [16908]={
    [1]={
      ["name"]="Bloodfang Hood",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16821]={
    [1]={
      ["name"]="Nightslayer Cover",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16823]={
    [1]={
      ["name"]="Nightslayer Shoulder Pads",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16820]={
    [1]={
      ["name"]="Nightslayer Chestpiece",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16825]={
    [1]={
      ["name"]="Nightslayer Bracelets",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16826]={
    [1]={
      ["name"]="Nightslayer Gloves",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16827]={
    [1]={
      ["name"]="Nightslayer Belt",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16909]={
    [1]={
      ["name"]="Bloodfang Pants",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16822]={
    [1]={
      ["name"]="Nightslayer Pants",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [16824]={
    [1]={
      ["name"]="Nightslayer Boots",["value"]="0",["note"]="",["role"]="Schurken"
    }
  },
  [19377]={
    [1]={
      ["name"]="Prestor's Talisman of Connivery",["value"]="100",["note"]="",["role"]="Schurken, Jäger"
    }
  },
  [16832]={
    [1]={
      ["name"]="Bloodfang Spaulders",["value"]="50",["note"]="",["role"]="Schurken"
    }
  },
  [16905]={
    [1]={
      ["name"]="Bloodfang Chestpiece",["value"]="50",["note"]="",["role"]="Schurken"
    }
  },
  [16911]={
    [1]={
      ["name"]="Bloodfang Bracers",["value"]="50",["note"]="",["role"]="Schurken"
    }
  },
  [16907]={
    [1]={
      ["name"]="Bloodfang Gloves",["value"]="50",["note"]="",["role"]="Schurken"
    }
  },
  [16910]={
    [1]={
      ["name"]="Bloodfang Belt",["value"]="50",["note"]="",["role"]="Schurken"
    }
  },
  [16906]={
    [1]={
      ["name"]="Bloodfang Boots",["value"]="50",["note"]="",["role"]="Schurken"
    }
  },
  [16939]={
    [1]={
      ["name"]="Dragonstalker's Helm",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16846]={
    [1]={
      ["name"]="Giantstalker's Helmet",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16848]={
    [1]={
      ["name"]="Giantstalker's Epaulets",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16845]={
    [1]={
      ["name"]="Giantstalker's Breastplate",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16850]={
    [1]={
      ["name"]="Giantstalker's Bracers",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16852]={
    [1]={
      ["name"]="Giantstalker's Gloves",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16851]={
    [1]={
      ["name"]="Giantstalker's Belt",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16938]={
    [1]={
      ["name"]="Dragonstalker's Legguards",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16847]={
    [1]={
      ["name"]="Giantstalker's Leggins",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16849]={
    [1]={
      ["name"]="Giantstalker's Boots",["value"]="0",["note"]="",["role"]="Jäger"
    }
  },
  [16937]={
    [1]={
      ["name"]="Dragonstalker's Spaulders",["value"]="50",["note"]="",["role"]="Jäger"
    }
  },
  [16942]={
    [1]={
      ["name"]="Dragonstalker's Breastplate",["value"]="50",["note"]="",["role"]="Jäger"
    }
  },
  [16935]={
    [1]={
      ["name"]="Dragonstalker's Bracers",["value"]="50",["note"]="",["role"]="Jäger"
    }
  },
  [16940]={
    [1]={
      ["name"]="Dragonstalker's Gauntlets",["value"]="50",["note"]="",["role"]="Jäger"
    }
  },
  [19380]={
    [1]={
      ["name"]="Therazane's Link",["value"]="100",["note"]="",["role"]="Jäger / Schamanen"
    }
  },
  [16941]={
    [1]={
      ["name"]="Dragonstalker's Greaves",["value"]="50",["note"]="",["role"]="Jäger"
    }
  },
  [19361]={
    [1]={
      ["name"]="Ashjre'thul, Crossbow of Smiting",["value"]="100",["note"]="",["role"]="Jäger"
    }
  },
  [16842]={
    [1]={
      ["name"]="Earthfury Helmet",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [16947]={
    [1]={
      ["name"]="Helmet of Ten Storms",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [18870]={
    [1]={
      ["name"]="Helm of the Lifegiver",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [18814]={
    [1]={
      ["name"]="Choker of the Firelord",["value"]="0",["note"]="Heiler gehen nach Strat UD!",["role"]="Caster DPS"
    }
  },
  [17109]={
    [1]={
      ["name"]="Choker of Enlightment",["value"]="0",["note"]="",["role"]="Caster DPS"
    }
  },
  [16844]={
    [1]={
      ["name"]="Earthfury Epaulets",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [18810]={
    [1]={
      ["name"]="Wild Growht Spaulders",["value"]="0",["note"]="",["role"]="Heildruiden, Heilschamanen"
    }
  },
  [18829]={
    [1]={
      ["name"]="Deep Eartth Spaulders",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [17078]={
    [1]={
      ["name"]="Sapphiron Drape",["value"]="0",["note"]="",["role"]="Caster DPS"
    }
  },
  [16841]={
    [1]={
      ["name"]="Earthfury Vestments",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [16840]={
    [1]={
      ["name"]="Earthfury Bracers ",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [16839]={
    [1]={
      ["name"]="Earthfury Gauntlets ",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [16838]={
    [1]={
      ["name"]="Earthfury Belt ",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [19136]={
    [1]={
      ["name"]="Mana Igniting Cord",["value"]="0",["note"]="",["role"]="Caster DPS"
    }
  },
  [16843]={
    [1]={
      ["name"]="Earthfury Legguards ",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [16946]={
    [1]={
      ["name"]="Legplates of Ten Storms",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [18875]={
    [1]={
      ["name"]="Salamander Scale Parts",["value"]="0",["note"]="",["role"]="Heilschamanen"
    }
  },
  [16837]={
    [1]={
      ["name"]="Earthfury Boots ",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [19140]={
    [1]={
      ["name"]="Cauterizing Band",["value"]="0",["note"]="",["role"]="Heiler"
    }
  },
  [19147]={
    [1]={
      ["name"]="Ring of Spell Power",["value"]="0",["note"]="",["role"]="Caster DPS"
    }
  },
  [17105]={
    [1]={
      ["name"]="Aurastone Hammer",["value"]="0",["note"]="",["role"]="Heilschamanen, Heildruiden"
    }
  },
  [18878]={
    [1]={
      ["name"]="Sorcerous Dagger",["value"]="0",["note"]="",["role"]="Caster DPS"
    }
  },
  [17106]={
    [1]={
      ["name"]="Malistar's Defender",["value"]="0",["note"]="",["role"]="Schamanen"
    }
  },
  [19142]={
    [1]={
      ["name"]="Fire Runed Grimoire",["value"]="0",["note"]="DPS Prio",["role"]="Caster DPS"
    }
  },
  [17064]={
    [1]={
      ["name"]="Shard of the Scale",["value"]="0",["note"]="",["role"]="1. Heilschamanen, 2. Heiler"
    }
  },
  [18820]={
    [1]={
      ["name"]="Talisman of Ephemeral Power",["value"]="0",["note"]="",["role"]="Caster DPS"
    }
  },
  [18842]={
    [1]={
      ["name"]="Staff of Dominance",["value"]="0",["note"]="",["role"]="1. Caster DPS, 2. Heildruiden"
    }
  },
  [18803]={
    [1]={
      ["name"]="Finkles Lava Dredger",["value"]="0",["note"]="",["role"]="Druiden, Schamanen"
    }
  },
  [19375]={
    [1]={
      ["name"]="Mish'undare, Circlet of the Mind Flayer",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [19371]={
    [1]={
      ["name"]="Pendant of the Fallen Dragon",["value"]="100",["note"]="",["role"]="Heilschamanen"
    }
  },
  [16945]={
    [1]={
      ["name"]="Epaulets of Ten Storms",["value"]="50",["note"]="",["role"]="Schamanen"
    }
  },
  [19373]={
    [1]={
      ["name"]="Black Brood Pauldrons",["value"]="100",["note"]="",["role"]="Schamanen"
    }
  },
  [19370]={
    [1]={
      ["name"]="Mantle of the Blackwing Cabal",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [19430]={
    [1]={
      ["name"]="Shroud of Pure Thought",["value"]="100",["note"]="",["role"]="Heiler"
    }
  },
  [19378]={
    [1]={
      ["name"]="Cloak of the Brood Lord",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [16950]={
    [1]={
      ["name"]="Breastplate of Ten Storms",["value"]="50",["note"]="",["role"]="Schamanen"
    }
  },
  [19399]={
    [1]={
      ["name"]="Black Ash Robe",["value"]="100",["note"]="",["role"]="Caster"
    }
  },
  [16943]={
    [1]={
      ["name"]="Bracers of Ten Storms",["value"]="50",["note"]="",["role"]="Schamanen"
    }
  },
  [19374]={
    [1]={
      ["name"]="Bracers of Arcane Accuracy",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [16948]={
    [1]={
      ["name"]="Gauntles of Ten Storms",["value"]="50",["note"]="",["role"]="Schamanen"
    }
  },
  [16944]={
    [1]={
      ["name"]="Belt of Ten Storms",["value"]="50",["note"]="",["role"]="Schamanen"
    }
  },
  [19385]={
    [1]={
      ["name"]="Empowered Leggings",["value"]="100",["note"]="",["role"]="Heiler"
    }
  },
  [19401]={
    [1]={
      ["name"]="Primalists Linked Legguards",["value"]="100",["note"]="",["role"]="Schamanen"
    }
  },
  [16949]={
    [1]={
      ["name"]="Greaves of Ten Storms",["value"]="50",["note"]="",["role"]="Schamanen"
    }
  },
  [19437]={
    [1]={
      ["name"]="Boots of Pure Thought",["value"]="100",["note"]="",["role"]="Heiler"
    }
  },
  [19391]={
    [1]={
      ["name"]="Shimmering Geta",["value"]="100",["note"]="",["role"]="Caster"
    }
  },
  [19382]={
    [1]={
      ["name"]="Pure Elementium Band",["value"]="100",["note"]="",["role"]="Heiler"
    }
  },
  [19397]={
    [1]={
      ["name"]="Ring of Blackrock",["value"]="100",["note"]="",["role"]="Caster"
    }
  },
  [19347]={
    [1]={
      ["name"]="Claw of Chromaggus",["value"]="100",["note"]="",["role"]="Heildruiden, Heilschamanen"
    }
  },
  [19360]={
    [1]={
      ["name"]="Lok amir il Romathis",["value"]="100",["note"]="",["role"]="Heiler"
    }
  },
  [19348]={
    [1]={
      ["name"]="Red Dragonscale Protector",["value"]="100",["note"]="",["role"]="Heilschamanen"
    }
  },
  [19395]={
    [1]={
      ["name"]="Rejuvenating Gem",["value"]="100",["note"]="",["role"]="Heiler"
    }
  },
  [19344]={
    [1]={
      ["name"]="Natural Alignment Crystal",["value"]="100",["note"]="",["role"]="Schamanen"
    }
  },
  [19355]={
    [1]={
      ["name"]="Shadow Wing Focus Staff",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [18817]={
    [1]={
      ["name"]="Crown of Destruction",["value"]="0",["note"]="",["role"]="Melee DPS"
    }
  },
  [19144]={
    [1]={
      ["name"]="Sabatons of the Flamewalker",["value"]="0",["note"]="",["role"]="Hunter, Schamanen"
    }
  },
  [19396]={
    [1]={
      ["name"]="Taut Dragonhide Belt",["value"]="100",["note"]="",["role"]="Ferals"
    }
  },
  [19433]={
    [1]={
      ["name"]="Emberweave Leggings",["value"]="100",["note"]="",["role"]="Schamanen / Jäger"
    }
  },
  [19376]={
    [1]={
      ["name"]="Archimtiros' Ring of Reckoning",["value"]="100",["note"]="",["role"]="Tanks"
    }
  },
  [16900]={
    [1]={
      ["name"]="Stormrage Cover",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16834]={
    [1]={
      ["name"]="Cenarion Helm",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16836]={
    [1]={
      ["name"]="Cenarion Spauldres",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16833]={
    [1]={
      ["name"]="Cenarion Vestments",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16830]={
    [1]={
      ["name"]="Cenarion Bracers",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16831]={
    [1]={
      ["name"]="Cenarion Gloves",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16828]={
    [1]={
      ["name"]="Cenarion Belt",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16835]={
    [1]={
      ["name"]="Cenarion Leggings",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16901]={
    [1]={
      ["name"]="Stormrage Legguards",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16829]={
    [1]={
      ["name"]="Cenarion Boots",["value"]="0",["note"]="",["role"]="Druiden"
    }
  },
  [16902]={
    [1]={
      ["name"]="Stormrage Pauldrons",["value"]="50",["note"]="",["role"]="Druiden"
    }
  },
  [16897]={
    [1]={
      ["name"]="Stormrage Chestguard",["value"]="50",["note"]="",["role"]="Druiden"
    }
  },
  [16904]={
    [1]={
      ["name"]="Stormrage Bracers",["value"]="50",["note"]="",["role"]="Druiden"
    }
  },
  [16899]={
    [1]={
      ["name"]="Stormrage Handguards",["value"]="50",["note"]="",["role"]="Druiden"
    }
  },
  [16903]={
    [1]={
      ["name"]="Stormrage Belt",["value"]="50",["note"]="",["role"]="Druiden"
    }
  },
  [16898]={
    [1]={
      ["name"]="Stormrage Boots",["value"]="50",["note"]="",["role"]="Druiden"
    }
  },
  [19366]={
    [1]={
      ["name"]="Master Dragonslayer's Orb",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [19340]={
    [1]={
      ["name"]="Rune of Metamorphosis",["value"]="100",["note"]="",["role"]="Druiden"
    }
  },
  [19139]={
    [1]={
      ["name"]="Fireguard Shoulders",["value"]="0",["note"]="",["role"]="Ferals, Schurken"
    }
  },
  [16929]={
    [1]={
      ["name"]="Nemesis Skullcap",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16808]={
    [1]={
      ["name"]="Felheart Horns",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16807]={
    [1]={
      ["name"]="Felheart Shoulder Pads",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16809]={
    [1]={
      ["name"]="Felheart Robes",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [19145]={
    [1]={
      ["name"]="Robe of Volatile Power",["value"]="0",["note"]="",["role"]="Caster DPS, Heildruiden"
    }
  },
  [16804]={
    [1]={
      ["name"]="Felheart Bracers",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16805]={
    [1]={
      ["name"]="Felheart Gloves",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16806]={
    [1]={
      ["name"]="Felheart Belt",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [18809]={
    [1]={
      ["name"]="Sash of Whispered Secrets",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16810]={
    [1]={
      ["name"]="Felheart Pants",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16930]={
    [1]={
      ["name"]="Nemesis Leggings",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [16803]={
    [1]={
      ["name"]="Felheart Slippers",["value"]="0",["note"]="",["role"]="Hexer"
    }
  },
  [17103]={
    [1]={
      ["name"]="Azuresong Mageblade",["value"]="0",["note"]="Droppt eh immer!",["role"]="Caster DPS"
    }
  },
  [17067]={
    [1]={
      ["name"]="Ancient Cornerstone Grimoire",["value"]="0",["note"]="",["role"]="Caster"
    }
  },
  [16932]={
    [1]={
      ["name"]="Nemesis Spaulders",["value"]="50",["note"]="",["role"]="Hexer"
    }
  },
  [16931]={
    [1]={
      ["name"]="Nemesis Robes",["value"]="50",["note"]="",["role"]="Hexer"
    }
  },
  [16934]={
    [1]={
      ["name"]="Nemesis Bracers",["value"]="50",["note"]="",["role"]="Hexer"
    }
  },
  [16928]={
    [1]={
      ["name"]="Nemesis Gloves",["value"]="50",["note"]="",["role"]="Hexer"
    }
  },
  [19407]={
    [1]={
      ["name"]="Ebony Flame Gloves",["value"]="100",["note"]="",["role"]="Hexer"
    }
  },
  [16933]={
    [1]={
      ["name"]="Nemesis Belt",["value"]="50",["note"]="",["role"]="Hexer"
    }
  },
  [19388]={
    [1]={
      ["name"]="Angelista's Grasp",["value"]="100",["note"]="",["role"]="Hexer"
    }
  },
  [16927]={
    [1]={
      ["name"]="Nemesis Boots",["value"]="50",["note"]="",["role"]="Hexer"
    }
  },
  [19434]={
    [1]={
      ["name"]="Band of Dark Dominion",["value"]="100",["note"]="",["role"]="Hexer"
    }
  },
  [19403]={
    [1]={
      ["name"]="Band of Forced Concentration",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [19337]={
    [1]={
      ["name"]="The Black Book",["value"]="100",["note"]="",["role"]="Hexer"
    }
  },
  [19379]={
    [1]={
      ["name"]="Neltharion's Tear",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [19356]={
    [1]={
      ["name"]="Staff of the Shadow Flame",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [19367]={
    [1]={
      ["name"]="Dragon's Touch",["value"]="100",["note"]="",["role"]="Caster"
    }
  },
  [16914]={
    [1]={
      ["name"]="Netherwind Crown",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16795]={
    [1]={
      ["name"]="Arcanist Crown",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16797]={
    [1]={
      ["name"]="Arcanist Mantle",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16798]={
    [1]={
      ["name"]="Arcanist Robes",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16799]={
    [1]={
      ["name"]="Arcanist Bindings",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16801]={
    [1]={
      ["name"]="Arcanist Gloves",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16802]={
    [1]={
      ["name"]="Arcanist Belt",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16915]={
    [1]={
      ["name"]="Netherwind Pants",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16796]={
    [1]={
      ["name"]="Arcanist Leggings",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16800]={
    [1]={
      ["name"]="Arcanist Boots",["value"]="0",["note"]="",["role"]="Magier"
    }
  },
  [16917]={
    [1]={
      ["name"]="Netherwind Mantle",["value"]="50",["note"]="",["role"]="Magier"
    }
  },
  [16916]={
    [1]={
      ["name"]="Netherwind Robes",["value"]="50",["note"]="",["role"]="Magier"
    }
  },
  [16918]={
    [1]={
      ["name"]="Netherwind Bindings",["value"]="50",["note"]="",["role"]="Magier"
    }
  },
  [16913]={
    [1]={
      ["name"]="Netherwind Gloves",["value"]="50",["note"]="",["role"]="Magier"
    }
  },
  [19400]={
    [1]={
      ["name"]="Firemaw's Clutch",["value"]="100",["note"]="",["role"]="Caster"
    }
  },
  [16818]={
    [1]={
      ["name"]="Netherwind Belt",["value"]="50",["note"]="",["role"]="Magier"
    }
  },
  [19438]={
    [1]={
      ["name"]="Ringo's Blizzard Boots",["value"]="100",["note"]="",["role"]="Frostmages"
    }
  },
  [16912]={
    [1]={
      ["name"]="Netherwind Boots",["value"]="50",["note"]="",["role"]="Magier"
    }
  },
  [19339]={
    [1]={
      ["name"]="Mind Quickening Gem",["value"]="100",["note"]="",["role"]="Magier"
    }
  },
  [16921]={
    [1]={
      ["name"]="Halo of Transcendence",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16813]={
    [1]={
      ["name"]="Circlet of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16816]={
    [1]={
      ["name"]="Mantle of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16815]={
    [1]={
      ["name"]="Robes of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16819]={
    [1]={
      ["name"]="Vambraces of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16812]={
    [1]={
      ["name"]="Gloves of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16817]={
    [1]={
      ["name"]="Girdle of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16922]={
    [1]={
      ["name"]="Leggings of Transcendence",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16814]={
    [1]={
      ["name"]="Pants of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16811]={
    [1]={
      ["name"]="Boots of Prophecy",["value"]="0",["note"]="",["role"]="Priester"
    }
  },
  [16924]={
    [1]={
      ["name"]="Pauldrons of Transcendence",["value"]="50",["note"]="",["role"]="Priester"
    }
  },
  [16923]={
    [1]={
      ["name"]="Robes of Transcendence",["value"]="50",["note"]="",["role"]="Priester"
    }
  },
  [16926]={
    [1]={
      ["name"]="Bindings of Transcendence",["value"]="50",["note"]="",["role"]="Priester"
    }
  },
  [16920]={
    [1]={
      ["name"]="Handguards of Transcendence",["value"]="50",["note"]="",["role"]="Priester"
    }
  },
  [19369]={
    [1]={
      ["name"]="Gloves of Rapid Evolution",["value"]="100",["note"]="",["role"]="Caster DPS"
    }
  },
  [16925]={
    [1]={
      ["name"]="Belt of Transcendence",["value"]="50",["note"]="",["role"]="Priester"
    }
  },
  [16919]={
    [1]={
      ["name"]="Boots of Transcendence",["value"]="50",["note"]="",["role"]="Priester"
    }
  },
  [19345]={
    [1]={
      ["name"]="Aegis of Preservation",["value"]="100",["note"]="",["role"]="Priester"
    }
  },
  [19435]={
    [1]={
      ["name"]="Essence Gatherer",["value"]="100",["note"]="",["role"]="Priester"
    }
  }
}
